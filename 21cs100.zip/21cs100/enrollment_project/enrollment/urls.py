from django.urls import path
from . import views
urlpatterns=[
    path('',views.enrollment_form,name='enrollment_form'),
     path('enroll/',views.enroll_student,name='enroll_student'),
]