from django.shortcuts import render
from django.http import JsonResponse
from .models import Student
from .forms import StudentEnrollmentForm
def enrollment_form(request):
    form=StudentEnrollmentForm()
    return render(request,'enrollment_form.html',{'form':form})
def enroll_student(request):
    if request.method=='POST' and request.headers.get('x-requested-with')=='XMLHttpRequest':
        form=StudentEnrollmentForm(request.POST)
        if form.is_valid():
            form.save()
            return JsonResponse({'message':'Enrollment successfull'})
        else:
            errors=form.errors.as_json()
            return JsonResponse({'errors':errors},status=400)
    return JsonResponse({'error':'Invalid request method or not AJAX'},status =400)

# Create your views here.
