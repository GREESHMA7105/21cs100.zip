from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
def app1(request):
    current_datetime=datetime.now()
    html="<html><body><b>Current date time value:</b>%s</body></html>"%current_datetime
    return HttpResponse(html)
# Create your views here.

