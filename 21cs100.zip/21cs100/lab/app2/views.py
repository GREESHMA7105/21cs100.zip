from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime,timedelta
def app2(request):
    current_datetime=datetime.now()
    delta=timedelta(hours=+4)
    new_time =delta+current_datetime
    before_time=current_datetime-delta
    html="<html><body><b>Current date time value:</b>%s"%current_datetime
    html1="<br><b>Current date time value + 4 hrs:</b>%s"%new_time
    html2=html+html1+"<br><b>Current date time value - 4 hrs:</b>%s</body></html>"%before_time

    return HttpResponse(html2)
# Create your views here.

