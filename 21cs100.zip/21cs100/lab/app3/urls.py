from django.urls import path
from . import views
urlpatterns=[path('app3/',views.app3,name='app3'),]