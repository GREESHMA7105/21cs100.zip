from django.shortcuts import render
def app3(request):
    fruits=['Apple','Mango','Banana','Grape']
    students=['Ram','Riya','Mohan','siya']
    context={
        'fruits':fruits,
        'students':students,
    }
    return render(request,'list.html',context,)
