from django.urls import path
from . import views
urlpatterns=[
    path('app4/',views.app4,name='app4'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    ]