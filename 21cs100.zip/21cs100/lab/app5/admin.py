from django.contrib import admin
from .models import Course, Student

class CourseAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

admin.site.register(Course, CourseAdmin)

class StudentAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email')
    filter_horizontal = ('courses',)

admin.site.register(Student, StudentAdmin)
