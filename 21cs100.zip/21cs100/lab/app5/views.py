from django.shortcuts import render, get_object_or_404
from .models import Course, Student
def index(request):
    courses=Course.objects.all()
    return render(request,'index.html',{'courses':courses})
def studentlist(request,course_id):
    course=Course.objects.get(id=course_id)
    students=course.students.all()
    return render(request,'studentlist.html',{'students':students,'course':course})