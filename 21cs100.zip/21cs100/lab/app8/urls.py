from django.urls import path
from app8.views import export_book_csv,export_book_pdf
urlpatterns=[
    path('books/export/csv/',export_book_csv,name='export_book_csv'),
    path('books/export/pdf/',export_book_pdf,name='export_book_pdf'),
]