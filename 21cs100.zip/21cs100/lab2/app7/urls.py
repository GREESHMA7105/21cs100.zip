from django.urls import path
from . import views
urlpatterns=[
    path("index/",views.index,name="index"),
    path("register_project/",views.register_project,name="register_project"),
    path("projectlist/<int:project_id>/",views.projectlist,name="projectlist"),
]