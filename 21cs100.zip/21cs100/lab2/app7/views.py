from django.shortcuts import render,redirect
from .models import Student,Project
from .forms import ProjectForm
def index(request):
    projects=Project.objects.all()
    return render(request,'index.html',{'projects':projects})
def projectlist(request,project_id):
    project=Project.objects.get(id=project_id)
    students_project=project.students_project.all()
    return render(request,'projectlist.html',{'students_project':students_project,'project':project})
def register_project(request):
    if request.method=='POST':
        form=ProjectForm(request.POST)
        if form.is_valid:
            project=form.save() 
        return redirect('index')
    else:
        form=ProjectForm()
    return render(request,'register_project.html',{'form':form})