from django.urls import path
from .views import search_student_courses
urlpatterns=[
    path('search',search_student_courses,name='search_student_courses'),
]