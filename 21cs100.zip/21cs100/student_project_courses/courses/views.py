from django.shortcuts import render
from django.http import JsonResponse
from .models import Student, Course

def search_student_courses(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        student_name = request.GET.get('student_name')  # Correctly use request.GET
        if student_name:
            try:
                student = Student.objects.get(name__iexact=student_name)  # Correct lookup method
                courses = student.courses.all()
                course_list = [course.name for course in courses]
                return JsonResponse({'courses': course_list}, status=200)
            except Student.DoesNotExist:
                return JsonResponse({'error': 'Student not found'}, status=400)
        else:
            return JsonResponse({'error': 'Student name not provided'}, status=400)
    return render(request, 'search_student.html')
